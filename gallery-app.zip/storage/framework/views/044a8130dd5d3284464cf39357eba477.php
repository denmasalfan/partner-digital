<?php echo e(\Filament\Facades\Filament::renderHook('footer.before')); ?>

<div class="filament-main-footer shrink-0 py-4">
    <div class="filament-footer flex items-center justify-center text-sm text-gray-500">
        &copy; <?php echo e(date('Y')); ?> <b>Partner Digital</b>. Hak Cipta Dilindungi.
    </div>
</div>
<?php echo e(\Filament\Facades\Filament::renderHook('footer.after')); ?>

<?php /**PATH C:\xampp\htdocs\gallery-app\vendor\filament\filament\resources\views/components/footer.blade.php ENDPATH**/ ?>