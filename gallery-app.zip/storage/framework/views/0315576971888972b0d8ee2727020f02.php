<div <?php echo e($attributes->merge($getExtraAttributes())); ?>>
    <?php echo e($getChildComponentContainer()); ?>

</div>
<?php /**PATH C:\xampp\htdocs\gallery-app\vendor\filament\forms\resources\views/components/group.blade.php ENDPATH**/ ?>