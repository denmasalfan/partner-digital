<td
    <?php echo e($attributes->class(['filament-tables-checkbox-cell w-4 whitespace-nowrap px-4'])); ?>

>
    <?php echo e($slot); ?>

</td>
<?php /**PATH C:\xampp\htdocs\gallery-app\vendor\filament\tables\resources\views/components/checkbox/cell.blade.php ENDPATH**/ ?>